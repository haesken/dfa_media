
if not(FILE)then
	names=ParseNames("dfusion/embark/races.txt")--io.open("plugins/embark/races.txt"):lines()
	embark(names)
end