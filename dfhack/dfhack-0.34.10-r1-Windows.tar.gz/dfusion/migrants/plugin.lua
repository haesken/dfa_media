
if not(FILE) then
	names=ParseNames("dfusion/migrants/races.txt")--io.open("plugins/migrants/races.txt"):lines()
	migrants(names)
end