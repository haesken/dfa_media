if not(FILE) then
	adv_tools.menu:display()
end