if not(FILE) then
	--tools.menu:add("Change site type",tools.changesite)
	--tools.menu:add("Change site flags",tools.changeflags)
	--tools.menu:add("Hostilate creature",tools.hostilate)
	--tools.menu:add("Print current mouse block",tools.mouseBlock)

	tools.menu:display()
end