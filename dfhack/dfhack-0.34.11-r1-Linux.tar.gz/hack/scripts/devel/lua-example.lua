-- Example of a lua script.

run_count = (run_count or 0) + 1

print('Arguments: ',...)
print('Command called '..run_count..' times.')
